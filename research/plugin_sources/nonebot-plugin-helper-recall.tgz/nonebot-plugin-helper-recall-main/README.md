# nonebot-plugin-helper-recall

✨ 帮撤回插件 ✨

帮助普通群员撤回自己因超时无法撤回的消息，需要bot被群主授予管理员权限(想给bot群主我也没意见(bushi))

## 功能

- 引用自己发送的消息，发送 `/撤回` 指令
- Bot 尝试撤回该消息

## 安装(指令二选一，无区别)

```bash
nb plugin install nonebot-plugin-helper-recall
pip install nonebot-plugin-helper-recall
```

## 使用

1. 确保 Bot 是群管理员
2. 群员引用自己发送的任意消息（包括超时的）
3. 在同一条消息中发送 `/撤回`
4. Bot 会撤回那条被引用的消息

## 注意事项

- 触发命令为 `/撤回`（引用消息后发送），日常聊天中提到"撤回"二字不会触发
- 仅支持撤回自己的消息
- 如果消息已超过 QQ 可撤回时间，会提示失败（不是两分钟那个
- 需要 Bot 有管理员权限
- 撤回失败的具体原因请查看 Bot 日志，不会在群里输出原始错误信息

## 配置

无需配置，即装即用

## 0.2.0 更新日志

- **修复**：触发条件过宽——此前任何包含"撤回"二字的聊天消息都会触发插件回复
  （甚至被引用的消息带"撤回"字样时会被真的撤回）；现改为标准 `/撤回` 命令触发
- **修复**：撤回成功后还会追加一条"撤回失败了喵"报错的问题
  （`finish()` 抛出的 `FinishedException` 被 `except Exception` 捕获所致）
- **修复**：撤回失败时把原始 API 错误信息直接发到群里（信息泄露），现只回友好提示，详情记录日志
- **修复**：私聊使用 `/撤回` 无响应（现提示仅支持群聊）
- **修复**：移除两个从未使用的依赖（nonebot-plugin-alconna、nonebot-plugin-localstore），
  安装体积大幅减小
- `requires-python` 提升至 3.10；补充 LICENSE 文件；
  移除误提交的 egg-info；新增测试套件（nonebug + pytest）

## 开发

```bash
pip install -e ".[test]"
pytest
```

## 开源协议

MIT
